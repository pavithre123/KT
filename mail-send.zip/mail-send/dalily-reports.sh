#!/bin/bash

python3 ss_grafana.py
python3 inline-mail.py
